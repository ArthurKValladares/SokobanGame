/*
 * Copyright (C) 2025 Muhammad Tayyab Akram
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef _SB_INTERNAL_ONCE_H
#define _SB_INTERNAL_ONCE_H

#include <API/SBBase.h>
#include <Core/AtomicFlag.h>
#include <Core/ThreadFence.h>

#if defined(HAS_ATOMIC_FLAG_SUPPORT) && defined(HAS_THREAD_FENCE_SUPPORT)
#define HAS_ONCE_SUPPORT
#endif

typedef struct _Once {
    SBBoolean executed;
    AtomicFlag flag;
} Once, *OnceRef;

#define OnceMake() { SBFalse, AtomicFlagMake() }

SB_INTERNAL SBBoolean OnceTryExecute(OnceRef once, void(*func)(void *info), void *info);

#endif
